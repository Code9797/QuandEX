package com.quanda.quandex.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TradeTicketTest {
    @Test
    fun buyTicket_acceptsValidLevels() {
        val ticket = TradeTicket(
            direction = Direction.BUY,
            entry = 2_640.0,
            stopLoss = 2_634.0,
            takeProfit = 2_652.0,
            lot = 0.01
        )

        assertNull(ticket.validationError())
        assertEquals(2.0, ticket.riskReward(), 0.0001)
    }

    @Test
    fun sellTicket_rejectsStopBelowEntry() {
        val ticket = TradeTicket(
            direction = Direction.SELL,
            entry = 2_640.0,
            stopLoss = 2_634.0,
            takeProfit = 2_628.0,
            lot = 0.01
        )

        assertEquals("SL ou TP placé du mauvais côté du prix", ticket.validationError())
    }

    @Test
    fun grid_requiresPositiveDistance() {
        val ticket = TradeTicket(
            direction = Direction.BUY,
            entry = 2_640.0,
            stopLoss = 2_634.0,
            takeProfit = 2_652.0,
            lot = 0.01,
            orderCount = 3,
            gridPoints = 0
        )

        assertEquals("La grille doit être supérieure à zéro", ticket.validationError())
    }
}
