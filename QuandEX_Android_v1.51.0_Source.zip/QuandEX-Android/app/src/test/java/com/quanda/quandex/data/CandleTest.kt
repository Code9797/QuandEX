package com.quanda.quandex.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CandleTest {
    @Test
    fun validBullishCandleIsAccepted() {
        val candle = Candle(
            time = 1_788_523_200_000,
            open = 2639.80,
            high = 2641.10,
            low = 2639.25,
            close = 2640.50,
            tickVolume = 186.0
        )

        assertTrue(candle.isValid())
        assertTrue(candle.bullish)
    }

    @Test
    fun candleWithHighBelowCloseIsRejected() {
        val candle = Candle(
            time = 1_788_523_200_000,
            open = 2639.80,
            high = 2640.00,
            low = 2639.25,
            close = 2640.50
        )

        assertFalse(candle.isValid())
    }
}
