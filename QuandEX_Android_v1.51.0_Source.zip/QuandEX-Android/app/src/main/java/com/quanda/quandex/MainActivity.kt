package com.quanda.quandex

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.quanda.quandex.ui.MainViewModel
import com.quanda.quandex.ui.QuandExApp
import com.quanda.quandex.ui.theme.QuandExTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            QuandExTheme {
                val viewModel: MainViewModel = viewModel()
                QuandExApp(viewModel)
            }
        }
    }
}
