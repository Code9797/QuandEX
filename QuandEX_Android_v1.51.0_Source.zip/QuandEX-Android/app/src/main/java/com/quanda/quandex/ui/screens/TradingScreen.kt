package com.quanda.quandex.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.quanda.quandex.data.Direction
import com.quanda.quandex.data.OrderType
import com.quanda.quandex.data.TradeTicket
import com.quanda.quandex.data.UiState
import com.quanda.quandex.ui.components.FormField
import com.quanda.quandex.ui.components.KeyValue
import com.quanda.quandex.ui.components.SectionCard
import com.quanda.quandex.ui.components.TradingButton
import com.quanda.quandex.ui.theme.Gold
import com.quanda.quandex.ui.theme.Green
import com.quanda.quandex.ui.theme.Muted
import com.quanda.quandex.ui.theme.Red
import java.util.Locale
import kotlin.math.max

@Composable
fun TradingScreen(
    state: UiState,
    onExecute: (TradeTicket) -> Unit,
    onClosePending: () -> Unit,
    onCloseAll: () -> Unit
) {
    val dashboard = state.snapshot.dashboard
    var direction by rememberSaveable { mutableStateOf(Direction.BUY) }
    var orderType by rememberSaveable { mutableStateOf(OrderType.MARKET) }
    var entry by rememberSaveable { mutableStateOf("") }
    var stopLoss by rememberSaveable { mutableStateOf("") }
    var takeProfit by rememberSaveable { mutableStateOf("") }
    var lot by rememberSaveable { mutableStateOf(state.settings.defaultLot.toString()) }
    var gridPoints by rememberSaveable { mutableStateOf("0") }
    var orderCount by rememberSaveable { mutableStateOf("1") }
    var trailing by rememberSaveable { mutableStateOf(true) }
    var keepGrid by rememberSaveable { mutableStateOf(false) }
    var confirmCloseAll by rememberSaveable { mutableStateOf(false) }

    fun loadMarketLevels() {
        val marketPrice = dashboard.lastPrice
        if (marketPrice <= 0.0) return
        val distance = max(dashboard.market.atrPoints / 100.0, 1.0)
        entry = formatPrice(marketPrice)
        stopLoss = formatPrice(if (direction == Direction.BUY) marketPrice - distance else marketPrice + distance)
        takeProfit = formatPrice(if (direction == Direction.BUY) marketPrice + distance * 2.0 else marketPrice - distance * 2.0)
    }

    LaunchedEffect(dashboard.lastPrice) {
        if (entry.isBlank()) loadMarketLevels()
    }

    if (confirmCloseAll) {
        AlertDialog(
            onDismissRequest = { confirmCloseAll = false },
            title = { Text("Confirmer CLOSE ALL") },
            text = { Text("Toutes les positions gérées par QuandEX seront fermées.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmCloseAll = false
                    onCloseAll()
                }) { Text("CONFIRMER", color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmCloseAll = false }) { Text("ANNULER") } }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Text("CONTRÔLE DE TRADING", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Ordres transmis à la passerelle GOLDEX / MT5", color = Muted, fontSize = 12.sp)
            }
        }

        item {
            SectionCard("TYPE D’ORDRE") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OrderType.entries.forEach { type ->
                        TradingButton(
                            text = type.name,
                            color = if (orderType == type) Gold else Muted,
                            onClick = { orderType = type },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item {
            SectionCard("DIRECTION") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TradingButton(
                        "BUY",
                        if (direction == Direction.BUY) Green else Muted,
                        {
                            direction = Direction.BUY
                            loadMarketLevels()
                        },
                        Modifier.weight(1f)
                    )
                    TradingButton(
                        "SELL",
                        if (direction == Direction.SELL) Red else Muted,
                        {
                            direction = Direction.SELL
                            loadMarketLevels()
                        },
                        Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            SectionCard("PRIX & PROTECTIONS") {
                TradingButton(
                    "UTILISER LE PRIX LIVE  ${formatPrice(dashboard.lastPrice)}",
                    Gold,
                    ::loadMarketLevels,
                    Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                FormField("Prix d’entrée", entry, { entry = it }, decimalKeyboard)
                Spacer(Modifier.height(8.dp))
                FormField("Stop Loss", stopLoss, { stopLoss = it }, decimalKeyboard)
                Spacer(Modifier.height(8.dp))
                FormField("Take Profit", takeProfit, { takeProfit = it }, decimalKeyboard)
                Spacer(Modifier.height(8.dp))
                FormField("Lot", lot, { lot = it }, decimalKeyboard)
            }
        }

        item {
            SectionCard("GRILLE & GESTION") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FormField(
                        "Distance (points)",
                        gridPoints,
                        { gridPoints = it.filter(Char::isDigit) },
                        integerKeyboard,
                        Modifier.weight(1f)
                    )
                    FormField(
                        "Nb ordres",
                        orderCount,
                        { orderCount = it.filter(Char::isDigit) },
                        integerKeyboard,
                        Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(10.dp))
                ToggleRow("Trailing stop", trailing) { trailing = it }
                ToggleRow("Maintenir la grille", keepGrid) { keepGrid = it }
            }
        }

        item {
            val ticket = TradeTicket(
                direction = direction,
                orderType = orderType,
                entry = entry.toDoubleOrNull() ?: 0.0,
                stopLoss = stopLoss.toDoubleOrNull() ?: 0.0,
                takeProfit = takeProfit.toDoubleOrNull() ?: 0.0,
                lot = lot.toDoubleOrNull() ?: 0.0,
                gridPoints = gridPoints.toIntOrNull() ?: 0,
                orderCount = orderCount.toIntOrNull() ?: 0,
                trailing = trailing,
                keepGrid = keepGrid
            )
            SectionCard("RÉCAPITULATIF") {
                KeyValue("Instrument", dashboard.symbol)
                Spacer(Modifier.height(7.dp))
                KeyValue("Ordre", "${direction.name} ${orderType.name}", if (direction == Direction.BUY) Green else Red)
                Spacer(Modifier.height(7.dp))
                KeyValue("Ratio risque/rendement", String.format(Locale.US, "%.2f", ticket.riskReward()), Gold)
                Spacer(Modifier.height(7.dp))
                KeyValue("Risque configuré", String.format(Locale.US, "%.2f%%", state.settings.defaultRiskPercent))
                Spacer(Modifier.height(12.dp))
                TradingButton(
                    "EXECUTE",
                    Gold,
                    { onExecute(ticket) },
                    Modifier.fillMaxWidth(),
                    !state.commandInProgress
                )
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TradingButton("CLOSE PENDING", Gold, onClosePending, Modifier.weight(1f), !state.commandInProgress)
                TradingButton("CLOSE ALL", Red, { confirmCloseAll = true }, Modifier.weight(1f), !state.commandInProgress)
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private val decimalKeyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal)
private val integerKeyboard = KeyboardOptions(keyboardType = KeyboardType.Number)

private fun formatPrice(value: Double): String =
    if (value > 0.0) String.format(Locale.US, "%.2f", value) else "--"
