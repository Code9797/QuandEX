package com.quanda.quandex.data

import com.quanda.quandex.network.QuandExApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class QuandExRepository(private val api: QuandExApi) {
    private val mutex = Mutex()
    private val demoEngine = DemoEngine()
    private val _snapshot = MutableStateFlow(Snapshot())
    val snapshot: StateFlow<Snapshot> = _snapshot.asStateFlow()

    suspend fun refresh(settings: AppSettings): Result<Snapshot> = mutex.withLock {
        runCatching {
            val next = if (settings.demoMode) demoEngine.snapshot(settings) else api.fetchSnapshot(settings)
            _snapshot.value = next
            next
        }
    }

    suspend fun command(settings: AppSettings, command: TradingCommand): Result<CommandResult> =
        mutex.withLock {
            runCatching {
                val result = if (settings.demoMode) {
                    demoEngine.command(settings, command)
                } else {
                    api.sendCommand(settings, command)
                }
                if (settings.demoMode) _snapshot.value = demoEngine.snapshot(settings)
                result
            }
        }
}

internal class DemoEngine {
    private var autoTrading = true
    private var sequence = 100_000L
    private val positions = mutableListOf<PositionItem>()
    private val signals = ArrayDeque<SignalItem>()
    private val candles = ArrayDeque<Candle>()
    private var candleBucket = Long.MIN_VALUE
    private var lastEvent = "Mode démonstration actif"

    fun snapshot(settings: AppSettings): Snapshot {
        val wave = sin(System.currentTimeMillis() / 12_000.0)
        val price = 2_640.0 + wave * 4.6
        updateCandles(price)
        val signal = when {
            wave > 0.35 -> Direction.BUY
            wave < -0.35 -> Direction.SELL
            else -> Direction.NEUTRAL
        }
        val trend = when {
            wave > 0.15 -> Trend.BULLISH
            wave < -0.15 -> Trend.BEARISH
            else -> Trend.NEUTRAL
        }
        val updatedPositions = positions.map { position ->
            val profitPoints = if (position.direction == Direction.BUY) {
                price - position.entry
            } else {
                position.entry - price
            }
            position.copy(currentPrice = price, profit = profitPoints * position.volume * 100.0)
        }
        positions.clear()
        positions.addAll(updatedPositions)
        val floating = updatedPositions.sumOf { it.profit }
        val stop = if (signal == Direction.SELL) price + 6.4 else price - 6.4
        val target = if (signal == Direction.SELL) price - 12.8 else price + 12.8
        val dashboard = Dashboard(
            symbol = settings.symbol,
            timeframe = "M5",
            connected = true,
            autoTrading = autoTrading,
            trend = trend,
            signal = signal,
            confidence = 62.0 + kotlin.math.abs(wave) * 24.0,
            strategy = if (signal == Direction.NEUTRAL) "Consensus en attente" else "EMA Pullback + Order Block",
            lastPrice = price,
            spreadPoints = 18.0 + kotlin.math.abs(wave) * 7.0,
            balance = 7_723.75,
            equity = 7_723.75 + floating,
            dailyProfit = 84.20 + floating,
            winRate7d = 68.4,
            riskPercent = settings.defaultRiskPercent,
            globalRiskPercent = positions.size * settings.defaultRiskPercent,
            estimatedLot = settings.defaultLot,
            dailyDrawdown = if (floating < 0) -floating / 7_723.75 * 100.0 else 0.0,
            dailyTrades = 3 + positions.size,
            lastEvent = lastEvent,
            risk = RiskLevels(stop, target, 640.0, true),
            market = MarketConditions(
                rsi = 50.0 + wave * 18.0,
                adx = 23.0 + kotlin.math.abs(wave) * 10.0,
                atrPoints = 640.0 + kotlin.math.abs(wave) * 90.0,
                regime = if (kotlin.math.abs(wave) > 0.55) "TENDANCE" else "RANGE",
                newsBlocked = false,
                session = "LONDRES–NEW YORK"
            ),
            smc = SmcState(
                bullishOrderBlock = wave > 0.25,
                bearishOrderBlock = wave < -0.25,
                bullishFvg = wave > 0.55,
                bearishFvg = wave < -0.55,
                orderBlockPrice = if (wave >= 0) price - 3.2 else price + 3.2
            ),
            mtf = listOf(
                TimeframeTrend("MN1", Trend.BULLISH),
                TimeframeTrend("D1", trend),
                TimeframeTrend("H4", trend),
                TimeframeTrend("H1", trend),
                TimeframeTrend("M15", if (wave > 0.0) Trend.BULLISH else Trend.BEARISH)
            )
        )
        return Snapshot(
            dashboard = dashboard,
            signals = signals.toList(),
            positions = positions.toList(),
            candles = candles.toList()
        )
    }

    private fun updateCandles(price: Double) {
        val intervalMillis = 5 * 60 * 1_000L
        val nowBucket = System.currentTimeMillis() / intervalMillis * intervalMillis

        if (candles.isEmpty()) {
            val firstBucket = nowBucket - 59 * intervalMillis
            var previousClose = price - 2.4
            repeat(60) { index ->
                val phase = (index - 59) / 5.5
                val close = if (index == 59) {
                    price
                } else {
                    price + sin(phase) * 3.4 + cos(phase * 0.63) * 1.25
                }
                val open = previousClose
                val wick = 0.35 + abs(sin(index * 1.37)) * 0.75
                candles.addLast(
                    Candle(
                        time = firstBucket + index * intervalMillis,
                        open = open,
                        high = max(open, close) + wick,
                        low = min(open, close) - wick * 0.82,
                        close = close,
                        tickVolume = 90.0 + abs(cos(index * 0.71)) * 180.0
                    )
                )
                previousClose = close
            }
            candleBucket = nowBucket
            return
        }

        if (nowBucket > candleBucket) {
            val open = candles.last().close
            candles.addLast(
                Candle(
                    time = nowBucket,
                    open = open,
                    high = max(open, price),
                    low = min(open, price),
                    close = price,
                    tickVolume = 1.0
                )
            )
            candleBucket = nowBucket
            while (candles.size > 80) candles.removeFirst()
        } else {
            val current = candles.removeLast()
            candles.addLast(
                current.copy(
                    high = max(current.high, price),
                    low = min(current.low, price),
                    close = price,
                    tickVolume = current.tickVolume + 1.0
                )
            )
        }
    }

    fun command(settings: AppSettings, command: TradingCommand): CommandResult {
        return when (command) {
            is TradingCommand.ToggleAuto -> {
                autoTrading = command.enabled
                lastEvent = if (autoTrading) "Trading automatique activé" else "Trading automatique suspendu"
                CommandResult(true, lastEvent, 1)
            }

            is TradingCommand.Execute -> {
                val error = command.ticket.validationError()
                if (error != null) return CommandResult(false, error)
                sequence += 1
                val ticket = command.ticket
                positions += PositionItem(
                    ticket = sequence,
                    symbol = settings.symbol,
                    direction = ticket.direction,
                    volume = ticket.lot,
                    entry = ticket.entry,
                    currentPrice = ticket.entry,
                    stopLoss = ticket.stopLoss,
                    takeProfit = ticket.takeProfit,
                    profit = 0.0,
                    comment = "QuandEX"
                )
                val now = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                signals.addFirst(
                    SignalItem(
                        id = sequence.toString(),
                        time = now,
                        symbol = settings.symbol,
                        timeframe = "M5",
                        direction = ticket.direction,
                        strategy = "Commande mobile",
                        confidence = 75.0,
                        entry = ticket.entry,
                        stopLoss = ticket.stopLoss,
                        takeProfit = ticket.takeProfit,
                        status = "EXÉCUTÉ"
                    )
                )
                while (signals.size > 20) signals.removeLast()
                lastEvent = "Ordre ${ticket.direction.name} #$sequence accepté"
                CommandResult(true, lastEvent, 1)
            }

            TradingCommand.CloseAll -> {
                val count = positions.size
                positions.clear()
                lastEvent = "$count position(s) fermée(s)"
                CommandResult(true, lastEvent, count)
            }

            TradingCommand.ClosePending -> {
                lastEvent = "Ordres en attente supprimés"
                CommandResult(true, lastEvent, 0)
            }

            is TradingCommand.ClosePosition -> {
                val removed = positions.removeAll { it.ticket == command.ticket }
                lastEvent = if (removed) "Position #${command.ticket} fermée" else "Position introuvable"
                CommandResult(removed, lastEvent, if (removed) 1 else 0)
            }
        }
    }
}
