package com.quanda.quandex.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.quanda.quandex.data.AppSettings
import com.quanda.quandex.ui.components.FormField
import com.quanda.quandex.ui.components.SectionCard
import com.quanda.quandex.ui.components.TradingButton
import com.quanda.quandex.ui.theme.Blue
import com.quanda.quandex.ui.theme.Gold
import com.quanda.quandex.ui.theme.Green
import com.quanda.quandex.ui.theme.Muted

@Composable
fun SettingsScreen(settings: AppSettings, onSave: (AppSettings) -> Unit) {
    var demoMode by rememberSaveable { mutableStateOf(settings.demoMode) }
    var apiUrl by rememberSaveable { mutableStateOf(settings.apiBaseUrl) }
    var apiToken by rememberSaveable { mutableStateOf(settings.apiToken) }
    var symbol by rememberSaveable { mutableStateOf(settings.symbol) }
    var refresh by rememberSaveable { mutableStateOf(settings.refreshSeconds.toString()) }
    var risk by rememberSaveable { mutableStateOf(settings.defaultRiskPercent.toString()) }
    var lot by rememberSaveable { mutableStateOf(settings.defaultLot.toString()) }

    LaunchedEffect(settings) {
        demoMode = settings.demoMode
        apiUrl = settings.apiBaseUrl
        apiToken = settings.apiToken
        symbol = settings.symbol
        refresh = settings.refreshSeconds.toString()
        risk = settings.defaultRiskPercent.toString()
        lot = settings.defaultLot.toString()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Text("RÉGLAGES", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Connexion sécurisée à votre passerelle MT5", color = Muted, fontSize = 12.sp)
            }
        }

        item {
            SectionCard("MODE DE FONCTIONNEMENT") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("Mode démonstration", color = Green, fontWeight = FontWeight.Bold)
                        Text("Simule les prix et les ordres sur l’appareil", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = demoMode, onCheckedChange = { demoMode = it })
                }
                if (!demoMode) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Le mode réel exige une passerelle HTTPS authentifiée connectée à GOLDEX EA PRO. L’application ne se connecte jamais directement au compte MT5.",
                        color = Blue,
                        fontSize = 12.sp
                    )
                }
            }
        }

        item {
            SectionCard("PASSERELLE GOLDEX") {
                FormField(
                    "URL API",
                    apiUrl,
                    { apiUrl = it.trim() },
                    KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                Spacer(Modifier.height(8.dp))
                FormField(
                    "Jeton d’accès",
                    apiToken,
                    { apiToken = it },
                    KeyboardOptions(keyboardType = KeyboardType.Password),
                    visualTransformation = PasswordVisualTransformation()
                )
            }
        }

        item {
            SectionCard("TRADING") {
                FormField(
                    "Symbole",
                    symbol,
                    { symbol = it.uppercase().take(16) },
                    KeyboardOptions(keyboardType = KeyboardType.Ascii)
                )
                Spacer(Modifier.height(8.dp))
                FormField(
                    "Actualisation (secondes)",
                    refresh,
                    { refresh = it.filter(Char::isDigit) },
                    KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(Modifier.height(8.dp))
                FormField(
                    "Risque par trade (%)",
                    risk,
                    { risk = it },
                    KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Spacer(Modifier.height(8.dp))
                FormField(
                    "Lot par défaut",
                    lot,
                    { lot = it },
                    KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        }

        item {
            TradingButton(
                "ENREGISTRER LES RÉGLAGES",
                Gold,
                onClick = {
                    onSave(
                        AppSettings(
                            demoMode = demoMode,
                            apiBaseUrl = apiUrl.ifBlank { settings.apiBaseUrl },
                            apiToken = apiToken,
                            symbol = symbol.ifBlank { "XAUUSD" },
                            refreshSeconds = (refresh.toIntOrNull() ?: 1).coerceIn(1, 60),
                            defaultRiskPercent = (risk.toDoubleOrNull() ?: 1.0).coerceIn(0.01, 10.0),
                            defaultLot = (lot.toDoubleOrNull() ?: 0.01).coerceAtLeast(0.01)
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Text(
                "Conseil : validez d’abord la passerelle en mode démonstration et sur un compte MT5 démo.",
                color = Muted,
                fontSize = 11.sp
            )
        }
    }
}
