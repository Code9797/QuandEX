package com.quanda.quandex.data

import kotlin.math.abs

enum class Direction { BUY, SELL, NEUTRAL }
enum class Trend { BULLISH, BEARISH, NEUTRAL }
enum class OrderType { MARKET, LIMIT, STOP }

data class TimeframeTrend(
    val timeframe: String,
    val trend: Trend
)

data class RiskLevels(
    val stopLoss: Double = 0.0,
    val takeProfit: Double = 0.0,
    val trailingPoints: Double = 0.0,
    val breakEvenEnabled: Boolean = true
)

data class MarketConditions(
    val rsi: Double = 0.0,
    val adx: Double = 0.0,
    val atrPoints: Double = 0.0,
    val regime: String = "INCONNU",
    val newsBlocked: Boolean = false,
    val session: String = "FERMÉE"
)

data class SmcState(
    val bullishOrderBlock: Boolean = false,
    val bearishOrderBlock: Boolean = false,
    val bullishFvg: Boolean = false,
    val bearishFvg: Boolean = false,
    val orderBlockPrice: Double = 0.0
)

data class Dashboard(
    val symbol: String = "XAUUSD",
    val timeframe: String = "M5",
    val connected: Boolean = false,
    val autoTrading: Boolean = false,
    val trend: Trend = Trend.NEUTRAL,
    val signal: Direction = Direction.NEUTRAL,
    val confidence: Double = 0.0,
    val strategy: String = "Aucun consensus",
    val lastPrice: Double = 0.0,
    val spreadPoints: Double = 0.0,
    val balance: Double = 0.0,
    val equity: Double = 0.0,
    val dailyProfit: Double = 0.0,
    val winRate7d: Double = 0.0,
    val riskPercent: Double = 1.0,
    val globalRiskPercent: Double = 0.0,
    val estimatedLot: Double = 0.01,
    val currency: String = "USD",
    val dailyDrawdown: Double = 0.0,
    val dailyTrades: Int = 0,
    val riskLocked: Boolean = false,
    val lastEvent: String = "Initialisation",
    val risk: RiskLevels = RiskLevels(),
    val market: MarketConditions = MarketConditions(),
    val smc: SmcState = SmcState(),
    val mtf: List<TimeframeTrend> = listOf(
        TimeframeTrend("MN1", Trend.NEUTRAL),
        TimeframeTrend("D1", Trend.NEUTRAL),
        TimeframeTrend("H4", Trend.NEUTRAL),
        TimeframeTrend("H1", Trend.NEUTRAL),
        TimeframeTrend("M15", Trend.NEUTRAL)
    )
)

data class SignalItem(
    val id: String,
    val time: String,
    val symbol: String,
    val timeframe: String,
    val direction: Direction,
    val strategy: String,
    val confidence: Double,
    val entry: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val status: String
)

data class PositionItem(
    val ticket: Long,
    val symbol: String,
    val direction: Direction,
    val volume: Double,
    val entry: Double,
    val currentPrice: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val profit: Double,
    val comment: String
)

data class Candle(
    val time: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val tickVolume: Double = 0.0
) {
    val bullish: Boolean get() = close >= open

    fun isValid(): Boolean =
        time > 0L && open > 0.0 && close > 0.0 &&
            high >= maxOf(open, close) && low <= minOf(open, close) && high > low
}

data class Snapshot(
    val dashboard: Dashboard = Dashboard(),
    val signals: List<SignalItem> = emptyList(),
    val positions: List<PositionItem> = emptyList(),
    val candles: List<Candle> = emptyList(),
    val receivedAt: Long = System.currentTimeMillis()
)

data class TradeTicket(
    val direction: Direction = Direction.BUY,
    val orderType: OrderType = OrderType.MARKET,
    val entry: Double = 0.0,
    val stopLoss: Double = 0.0,
    val takeProfit: Double = 0.0,
    val lot: Double = 0.01,
    val gridPoints: Int = 0,
    val orderCount: Int = 1,
    val trailing: Boolean = true,
    val keepGrid: Boolean = false
) {
    fun validationError(): String? {
        if (direction == Direction.NEUTRAL) return "Sélectionnez BUY ou SELL"
        if (lot <= 0.0) return "Le lot doit être supérieur à zéro"
        if (orderCount !in 1..20) return "Le nombre d’ordres doit être compris entre 1 et 20"
        if (orderCount > 1 && gridPoints <= 0) return "La grille doit être supérieure à zéro"
        if (entry <= 0.0 || stopLoss <= 0.0 || takeProfit <= 0.0) return "Prix, SL et TP obligatoires"
        val levelsOk = if (direction == Direction.BUY) {
            stopLoss < entry && takeProfit > entry
        } else {
            stopLoss > entry && takeProfit < entry
        }
        if (!levelsOk) return "SL ou TP placé du mauvais côté du prix"
        return null
    }

    fun riskReward(): Double {
        val risk = abs(entry - stopLoss)
        return if (risk > 0.0) abs(takeProfit - entry) / risk else 0.0
    }
}

data class AppSettings(
    val demoMode: Boolean = true,
    val apiBaseUrl: String = "https://votre-passerelle.example.com",
    val apiToken: String = "",
    val symbol: String = "XAUUSD",
    val refreshSeconds: Int = 1,
    val defaultRiskPercent: Double = 1.0,
    val defaultLot: Double = 0.01
)

sealed interface TradingCommand {
    data class ToggleAuto(val enabled: Boolean) : TradingCommand
    data class Execute(val ticket: TradeTicket) : TradingCommand
    data object CloseAll : TradingCommand
    data object ClosePending : TradingCommand
    data class ClosePosition(val ticket: Long) : TradingCommand
}

data class CommandResult(
    val accepted: Boolean,
    val message: String,
    val affectedCount: Int = 0
)

data class UiState(
    val settings: AppSettings = AppSettings(),
    val snapshot: Snapshot = Snapshot(),
    val loading: Boolean = true,
    val commandInProgress: Boolean = false,
    val message: String? = null
)
