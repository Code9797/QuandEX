package com.quanda.quandex.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.quandExDataStore by preferencesDataStore(name = "quandex_settings")

class SettingsRepository(private val context: Context) {
    private object Keys {
        val demoMode = booleanPreferencesKey("demo_mode")
        val apiBaseUrl = stringPreferencesKey("api_base_url")
        val apiToken = stringPreferencesKey("api_token")
        val symbol = stringPreferencesKey("symbol")
        val refreshSeconds = intPreferencesKey("refresh_seconds")
        val riskPercent = doublePreferencesKey("risk_percent")
        val defaultLot = doublePreferencesKey("default_lot")
    }

    val settings: Flow<AppSettings> = context.quandExDataStore.data.map { values ->
        AppSettings(
            demoMode = values[Keys.demoMode] ?: true,
            apiBaseUrl = values[Keys.apiBaseUrl] ?: "https://votre-passerelle.example.com",
            apiToken = values[Keys.apiToken] ?: "",
            symbol = values[Keys.symbol] ?: "XAUUSD",
            refreshSeconds = (values[Keys.refreshSeconds] ?: 1).coerceIn(1, 60),
            defaultRiskPercent = (values[Keys.riskPercent] ?: 1.0).coerceIn(0.01, 10.0),
            defaultLot = (values[Keys.defaultLot] ?: 0.01).coerceAtLeast(0.01)
        )
    }

    suspend fun save(value: AppSettings) {
        context.quandExDataStore.edit { settings ->
            settings[Keys.demoMode] = value.demoMode
            settings[Keys.apiBaseUrl] = value.apiBaseUrl.trim().trimEnd('/')
            settings[Keys.apiToken] = value.apiToken.trim()
            settings[Keys.symbol] = value.symbol.trim().uppercase().ifBlank { "XAUUSD" }
            settings[Keys.refreshSeconds] = value.refreshSeconds.coerceIn(1, 60)
            settings[Keys.riskPercent] = value.defaultRiskPercent.coerceIn(0.01, 10.0)
            settings[Keys.defaultLot] = value.defaultLot.coerceAtLeast(0.01)
        }
    }
}
