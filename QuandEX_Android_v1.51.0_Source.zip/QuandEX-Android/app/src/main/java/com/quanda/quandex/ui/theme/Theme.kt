package com.quanda.quandex.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFFFB703)
val Green = Color(0xFF19E66B)
val Red = Color(0xFFFF3B47)
val Blue = Color(0xFF35B9FF)
val Night = Color(0xFF050A0F)
val Panel = Color(0xFF0B141B)
val Card = Color(0xFF101D25)
val Border = Color(0xFF33434E)
val Muted = Color(0xFFAFC3CF)

private val QuandExColors = darkColorScheme(
    primary = Gold,
    onPrimary = Night,
    secondary = Green,
    onSecondary = Night,
    tertiary = Blue,
    background = Night,
    onBackground = Color.White,
    surface = Panel,
    onSurface = Color.White,
    surfaceVariant = Card,
    onSurfaceVariant = Muted,
    error = Red,
    outline = Border
)

@Composable
fun QuandExTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = QuandExColors,
        content = content
    )
}
