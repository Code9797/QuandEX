package com.quanda.quandex.ui.components

import android.graphics.Paint as NativePaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.quanda.quandex.data.Candle
import com.quanda.quandex.data.Dashboard
import com.quanda.quandex.ui.theme.Border
import com.quanda.quandex.ui.theme.Card as CardColor
import com.quanda.quandex.ui.theme.Gold
import com.quanda.quandex.ui.theme.Green
import com.quanda.quandex.ui.theme.Muted
import com.quanda.quandex.ui.theme.Night
import com.quanda.quandex.ui.theme.Red
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val EmaFast = Color(0xFFFFB300)
private val EmaSlow = Color(0xFF20A4F3)
private val Grid = Color(0xFF26323B)

@Composable
fun LiveCandlestickPanel(
    dashboard: Dashboard,
    candles: List<Candle>,
    modifier: Modifier = Modifier
) {
    val visible = remember(candles) { candles.filter(Candle::isValid).takeLast(48) }
    var selectedIndex by remember(visible.size) { mutableStateOf(visible.lastIndex) }
    val selected = visible.getOrNull(selectedIndex.coerceIn(0, max(visible.lastIndex, 0)))

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardColor),
        border = BorderStroke(1.dp, Border),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "GRAPHIQUE BOUGIES EN TEMPS RÉEL",
                        color = Gold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${dashboard.symbol}  •  ${dashboard.timeframe}  •  ${visible.size} BOUGIES",
                        color = Muted,
                        fontSize = 10.sp
                    )
                }
                Text(
                    if (dashboard.connected) "● LIVE" else "● HORS LIGNE",
                    color = if (dashboard.connected) Green else Red,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Legend("HAUSSE", Green)
                Legend("BAISSE", Red)
                Legend("EMA 20", EmaFast)
                Legend("EMA 50", EmaSlow)
                Legend("OB/FVG", Gold)
            }

            Spacer(Modifier.height(7.dp))
            if (selected != null) {
                Text(
                    "O ${price(selected.open)}   H ${price(selected.high)}   " +
                        "L ${price(selected.low)}   C ${price(selected.close)}   " +
                        "V ${selected.tickVolume.toInt()}",
                    color = Color.White,
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }
            Spacer(Modifier.height(5.dp))

            if (visible.isEmpty()) {
                Box(
                    Modifier.fillMaxWidth().height(270.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Données OHLC indisponibles", color = Muted, fontSize = 12.sp)
                }
            } else {
                val closes = remember(visible) { visible.map { it.close } }
                val ema20 = remember(closes) { emaSeries(closes, 20) }
                val ema50 = remember(closes) { emaSeries(closes, 50) }
                val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(290.dp)
                        .pointerInput(visible.size) {
                            detectTapGestures { tap ->
                                val plotWidth = size.width * 0.84f
                                val step = plotWidth / visible.size.coerceAtLeast(1)
                                selectedIndex = (tap.x / step).toInt().coerceIn(0, visible.lastIndex)
                            }
                        }
                ) {
                    val topPadding = 10.dp.toPx()
                    val bottomAxis = 24.dp.toPx()
                    val rightAxis = 64.dp.toPx()
                    val plotWidth = (size.width - rightAxis).coerceAtLeast(1f)
                    val plotHeight = (size.height - topPadding - bottomAxis).coerceAtLeast(1f)
                    val rawLow = visible.minOf { it.low }
                    val rawHigh = visible.maxOf { it.high }
                    val padding = ((rawHigh - rawLow) * 0.08).coerceAtLeast(0.01)
                    val minPrice = rawLow - padding
                    val maxPrice = rawHigh + padding
                    val priceRange = (maxPrice - minPrice).coerceAtLeast(0.01)
                    val step = plotWidth / visible.size
                    val bodyWidth = (step * 0.58f).coerceIn(2.dp.toPx(), 13.dp.toPx())
                    val dash = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 5.dp.toPx()))

                    fun y(price: Double): Float =
                        topPadding + ((maxPrice - price) / priceRange * plotHeight).toFloat()

                    drawRect(Night, size = Size(plotWidth, topPadding + plotHeight))

                    val labelPaint = NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply {
                        color = Muted.toArgb()
                        textSize = 9.dp.toPx()
                        textAlign = NativePaint.Align.LEFT
                    }
                    repeat(5) { index ->
                        val ratio = index / 4f
                        val gridY = topPadding + plotHeight * ratio
                        val gridPrice = maxPrice - priceRange * ratio
                        drawLine(Grid, Offset(0f, gridY), Offset(plotWidth, gridY), 1.dp.toPx())
                        drawContext.canvas.nativeCanvas.drawText(
                            price(gridPrice),
                            plotWidth + 5.dp.toPx(),
                            gridY + 3.dp.toPx(),
                            labelPaint
                        )
                    }
                    repeat(7) { index ->
                        val gridX = plotWidth * index / 6f
                        drawLine(Grid, Offset(gridX, topPadding), Offset(gridX, topPadding + plotHeight), 1.dp.toPx())
                    }

                    val maxVolume = visible.maxOf { it.tickVolume }.coerceAtLeast(1.0)
                    visible.forEachIndexed { index, candle ->
                        val x = step * (index + 0.5f)
                        val volumeHeight = (candle.tickVolume / maxVolume * plotHeight * 0.16).toFloat()
                        val candleColor = if (candle.bullish) Green else Red
                        drawRect(
                            candleColor.copy(alpha = 0.14f),
                            topLeft = Offset(x - bodyWidth / 2f, topPadding + plotHeight - volumeHeight),
                            size = Size(bodyWidth, volumeHeight)
                        )
                    }

                    visible.indices.drop(2).filter { index ->
                        visible[index].low > visible[index - 2].high ||
                            visible[index].high < visible[index - 2].low
                    }.takeLast(4).forEach { index ->
                        val bullish = visible[index].low > visible[index - 2].high
                        val upper = if (bullish) visible[index].low else visible[index - 2].low
                        val lower = if (bullish) visible[index - 2].high else visible[index].high
                        val top = min(y(upper), y(lower))
                        val bottom = max(y(upper), y(lower))
                        val left = step * (index - 1.5f)
                        drawRect(
                            if (bullish) Green.copy(alpha = 0.10f) else Red.copy(alpha = 0.10f),
                            topLeft = Offset(left, top),
                            size = Size(plotWidth - left, max(bottom - top, 2.dp.toPx()))
                        )
                    }

                    if (dashboard.smc.orderBlockPrice in minPrice..maxPrice) {
                        val orderBlockY = y(dashboard.smc.orderBlockPrice)
                        val zoneHeight = 13.dp.toPx()
                        val obColor = if (dashboard.smc.bearishOrderBlock) Red else Gold
                        drawRect(
                            obColor.copy(alpha = 0.12f),
                            topLeft = Offset(plotWidth * 0.62f, orderBlockY - zoneHeight / 2f),
                            size = Size(plotWidth * 0.38f, zoneHeight)
                        )
                        drawLine(obColor, Offset(plotWidth * 0.62f, orderBlockY), Offset(plotWidth, orderBlockY), 1.dp.toPx())
                    }

                    visible.forEachIndexed { index, candle ->
                        val x = step * (index + 0.5f)
                        val color = if (candle.bullish) Green else Red
                        val openY = y(candle.open)
                        val closeY = y(candle.close)
                        drawLine(color, Offset(x, y(candle.high)), Offset(x, y(candle.low)), 1.dp.toPx())
                        drawRect(
                            color,
                            topLeft = Offset(x - bodyWidth / 2f, min(openY, closeY)),
                            size = Size(bodyWidth, max(abs(closeY - openY), 1.5.dp.toPx()))
                        )
                    }

                    fun drawEma(values: List<Double>, color: Color) {
                        val path = Path()
                        values.forEachIndexed { index, value ->
                            val point = Offset(step * (index + 0.5f), y(value))
                            if (index == 0) path.moveTo(point.x, point.y) else path.lineTo(point.x, point.y)
                        }
                        drawPath(path, color, style = androidx.compose.ui.graphics.drawscope.Stroke(1.5.dp.toPx()))
                    }
                    drawEma(ema50, EmaSlow)
                    drawEma(ema20, EmaFast)

                    fun drawRiskLevel(value: Double, color: Color) {
                        if (value in minPrice..maxPrice) {
                            val levelY = y(value)
                            drawLine(color.copy(alpha = 0.8f), Offset(0f, levelY), Offset(plotWidth, levelY), 1.dp.toPx(), pathEffect = dash)
                        }
                    }
                    drawRiskLevel(dashboard.risk.stopLoss, Red)
                    drawRiskLevel(dashboard.risk.takeProfit, Green)

                    val currentPrice = dashboard.lastPrice.takeIf { it > 0.0 } ?: visible.last().close
                    if (currentPrice in minPrice..maxPrice) {
                        val currentY = y(currentPrice)
                        drawLine(Gold, Offset(0f, currentY), Offset(plotWidth, currentY), 1.dp.toPx(), pathEffect = dash)
                        drawRect(
                            Gold,
                            topLeft = Offset(plotWidth, currentY - 9.dp.toPx()),
                            size = Size(rightAxis, 18.dp.toPx())
                        )
                        labelPaint.color = Night.toArgb()
                        labelPaint.textAlign = NativePaint.Align.CENTER
                        labelPaint.textSize = 9.dp.toPx()
                        labelPaint.isFakeBoldText = true
                        drawContext.canvas.nativeCanvas.drawText(
                            price(currentPrice),
                            plotWidth + rightAxis / 2f,
                            currentY + 3.dp.toPx(),
                            labelPaint
                        )
                    }

                    val selectedPosition = selectedIndex.coerceIn(0, visible.lastIndex)
                    val selectedX = step * (selectedPosition + 0.5f)
                    drawLine(Color.White.copy(alpha = 0.42f), Offset(selectedX, topPadding), Offset(selectedX, topPadding + plotHeight), 1.dp.toPx(), pathEffect = dash)
                    drawCircle(Color.White, 2.5.dp.toPx(), Offset(selectedX, y(visible[selectedPosition].close)))

                    labelPaint.color = Muted.toArgb()
                    labelPaint.textAlign = NativePaint.Align.CENTER
                    labelPaint.textSize = 9.dp.toPx()
                    labelPaint.isFakeBoldText = false
                    listOf(0, visible.lastIndex / 2, visible.lastIndex).distinct().forEach { index ->
                        drawContext.canvas.nativeCanvas.drawText(
                            timeFormat.format(Date(visible[index].time)),
                            step * (index + 0.5f),
                            size.height - 4.dp.toPx(),
                            labelPaint
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Legend(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(7.dp)) { drawCircle(color) }
        }
        Text("  $label", color = Muted, fontSize = 8.sp, maxLines = 1)
    }
}

private fun emaSeries(values: List<Double>, period: Int): List<Double> {
    if (values.isEmpty()) return emptyList()
    val multiplier = 2.0 / (period + 1.0)
    var ema = values.first()
    return values.mapIndexed { index, value ->
        if (index == 0) {
            ema = value
        } else {
            ema = value * multiplier + ema * (1.0 - multiplier)
        }
        ema
    }
}

private fun price(value: Double): String = String.format(Locale.US, "%.2f", value)
