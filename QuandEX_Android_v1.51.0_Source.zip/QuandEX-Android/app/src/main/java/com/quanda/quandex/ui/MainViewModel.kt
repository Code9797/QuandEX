package com.quanda.quandex.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.quanda.quandex.data.AppSettings
import com.quanda.quandex.data.Direction
import com.quanda.quandex.data.QuandExRepository
import com.quanda.quandex.data.SettingsRepository
import com.quanda.quandex.data.TradeTicket
import com.quanda.quandex.data.TradingCommand
import com.quanda.quandex.data.UiState
import com.quanda.quandex.network.QuandExApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val settingsRepository = SettingsRepository(application)
    private val repository = QuandExRepository(QuandExApi())
    private val loading = MutableStateFlow(true)
    private val commandInProgress = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)
    private var firstRefresh = true

    private val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        AppSettings()
    )

    val uiState: StateFlow<UiState> = combine(
        settings,
        repository.snapshot,
        loading,
        commandInProgress,
        message
    ) { appSettings, snapshot, isLoading, commandBusy, info ->
        UiState(appSettings, snapshot, isLoading, commandBusy, info)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState())

    init {
        viewModelScope.launch {
            settings.collectLatest { current ->
                while (isActive) {
                    refresh(current)
                    delay(current.refreshSeconds.coerceIn(1, 60) * 1_000L)
                }
            }
        }
    }

    fun refreshNow() {
        viewModelScope.launch { refresh(settings.value) }
    }

    fun toggleAuto() {
        send(TradingCommand.ToggleAuto(!repository.snapshot.value.dashboard.autoTrading))
    }

    fun quickTrade(direction: Direction) {
        val dashboard = repository.snapshot.value.dashboard
        val entry = dashboard.lastPrice
        if (entry <= 0.0) {
            message.value = "Prix de marché indisponible"
            return
        }
        val atrDistance = max(dashboard.market.atrPoints / 100.0, 1.0)
        val stop = if (direction == Direction.BUY) entry - atrDistance else entry + atrDistance
        val target = if (direction == Direction.BUY) entry + atrDistance * 2.0 else entry - atrDistance * 2.0
        send(
            TradingCommand.Execute(
                TradeTicket(
                    direction = direction,
                    entry = entry,
                    stopLoss = stop,
                    takeProfit = target,
                    lot = settings.value.defaultLot
                )
            )
        )
    }

    fun execute(ticket: TradeTicket) {
        val validation = ticket.validationError()
        if (validation != null) {
            message.value = validation
            return
        }
        send(TradingCommand.Execute(ticket))
    }

    fun closeAll() = send(TradingCommand.CloseAll)
    fun closePending() = send(TradingCommand.ClosePending)
    fun closePosition(ticket: Long) = send(TradingCommand.ClosePosition(ticket))

    fun saveSettings(value: AppSettings) {
        viewModelScope.launch {
            runCatching { settingsRepository.save(value) }
                .onSuccess { message.value = "Réglages enregistrés" }
                .onFailure { message.value = it.message ?: "Échec de l’enregistrement" }
        }
    }

    fun consumeMessage() {
        message.value = null
    }

    private suspend fun refresh(current: AppSettings) {
        if (firstRefresh) loading.value = true
        repository.refresh(current)
            .onFailure { message.value = it.message ?: "Connexion impossible" }
        loading.value = false
        firstRefresh = false
    }

    private fun send(command: TradingCommand) {
        if (commandInProgress.value) return
        viewModelScope.launch {
            commandInProgress.value = true
            repository.command(settings.value, command)
                .onSuccess { result -> message.value = result.message }
                .onFailure { error -> message.value = error.message ?: "Commande refusée" }
            if (!settings.value.demoMode) repository.refresh(settings.value)
            commandInProgress.value = false
        }
    }
}
