package com.quanda.quandex.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.quanda.quandex.data.Direction
import com.quanda.quandex.data.PositionItem
import com.quanda.quandex.ui.components.DirectionPill
import com.quanda.quandex.ui.components.EmptyState
import com.quanda.quandex.ui.components.KeyValue
import com.quanda.quandex.ui.components.SectionCard
import com.quanda.quandex.ui.components.TradingButton
import com.quanda.quandex.ui.theme.Gold
import com.quanda.quandex.ui.theme.Green
import com.quanda.quandex.ui.theme.Muted
import com.quanda.quandex.ui.theme.Red
import java.util.Locale

@Composable
fun PositionsScreen(
    positions: List<PositionItem>,
    commandInProgress: Boolean,
    onClose: (Long) -> Unit,
    onCloseAll: () -> Unit
) {
    var pendingTicket by remember { mutableStateOf<Long?>(null) }
    var confirmCloseAll by remember { mutableStateOf(false) }

    if (pendingTicket != null || confirmCloseAll) {
        AlertDialog(
            onDismissRequest = {
                pendingTicket = null
                confirmCloseAll = false
            },
            title = { Text(if (confirmCloseAll) "Fermer toutes les positions ?" else "Fermer #$pendingTicket ?") },
            text = { Text("La fermeture sera envoyée immédiatement à QuandEX / GOLDEX.") },
            confirmButton = {
                TextButton(onClick = {
                    if (confirmCloseAll) onCloseAll() else pendingTicket?.let(onClose)
                    pendingTicket = null
                    confirmCloseAll = false
                }) { Text("FERMER", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingTicket = null
                    confirmCloseAll = false
                }) { Text("ANNULER") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("POSITIONS", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("${positions.size} position(s) ouverte(s)", color = Muted, fontSize = 12.sp)
                }
                if (positions.isNotEmpty()) {
                    TradingButton(
                        "CLOSE ALL",
                        Red,
                        { confirmCloseAll = true },
                        enabled = !commandInProgress
                    )
                }
            }
        }
        if (positions.isEmpty()) {
            item { EmptyState("Aucune position ouverte") }
        } else {
            items(positions, key = { it.ticket }) { position ->
                PositionCard(position, !commandInProgress) { pendingTicket = position.ticket }
            }
        }
    }
}

@Composable
private fun PositionCard(position: PositionItem, enabled: Boolean, onClose: () -> Unit) {
    val profitColor: Color = if (position.profit >= 0.0) Green else Red
    SectionCard("#${position.ticket}  •  ${position.symbol}") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            DirectionPill(position.direction)
            Text(
                String.format(Locale.US, "%+.2f USD", position.profit),
                color = profitColor,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(10.dp))
        KeyValue("Volume", String.format(Locale.US, "%.2f lot", position.volume))
        Spacer(Modifier.height(7.dp))
        KeyValue("Entrée", p(position.entry))
        Spacer(Modifier.height(7.dp))
        KeyValue("Prix actuel", p(position.currentPrice), profitColor)
        Spacer(Modifier.height(7.dp))
        KeyValue("Stop Loss", p(position.stopLoss))
        Spacer(Modifier.height(7.dp))
        KeyValue("Take Profit", p(position.takeProfit))
        Spacer(Modifier.height(7.dp))
        KeyValue("Commentaire", position.comment)
        Spacer(Modifier.height(12.dp))
        TradingButton("FERMER LA POSITION", Red, onClose, Modifier.fillMaxWidth(), enabled)
    }
}

private fun p(value: Double) = String.format(Locale.US, "%.2f", value)
