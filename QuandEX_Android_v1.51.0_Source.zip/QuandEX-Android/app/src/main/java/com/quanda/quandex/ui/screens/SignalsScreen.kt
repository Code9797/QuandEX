package com.quanda.quandex.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.quanda.quandex.data.SignalItem
import com.quanda.quandex.ui.components.DirectionPill
import com.quanda.quandex.ui.components.EmptyState
import com.quanda.quandex.ui.components.KeyValue
import com.quanda.quandex.ui.components.SectionCard
import com.quanda.quandex.ui.theme.Gold
import com.quanda.quandex.ui.theme.Muted
import java.util.Locale

@Composable
fun SignalsScreen(signals: List<SignalItem>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Text("SIGNAUX QUANDEX", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Historique des détections et commandes mobiles", color = Muted, fontSize = 12.sp)
            }
        }
        if (signals.isEmpty()) {
            item { EmptyState("Aucun signal pour le moment") }
        } else {
            items(signals, key = { it.id }) { signal ->
                SectionCard("${signal.symbol}  •  ${signal.timeframe}  •  ${signal.time}") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        DirectionPill(signal.direction)
                        Text(signal.status, color = Gold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    KeyValue("Stratégie", signal.strategy)
                    Spacer(Modifier.height(7.dp))
                    KeyValue("Confiance", String.format(Locale.US, "%.1f%%", signal.confidence), Gold)
                    Spacer(Modifier.height(7.dp))
                    KeyValue("Entrée", price(signal.entry))
                    Spacer(Modifier.height(7.dp))
                    KeyValue("Stop Loss", price(signal.stopLoss))
                    Spacer(Modifier.height(7.dp))
                    KeyValue("Take Profit", price(signal.takeProfit))
                }
            }
        }
    }
}

private fun price(value: Double): String = String.format(Locale.US, "%.2f", value)
