package com.quanda.quandex.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.quanda.quandex.data.Direction
import com.quanda.quandex.data.Trend
import com.quanda.quandex.ui.theme.Border
import com.quanda.quandex.ui.theme.Card as CardColor
import com.quanda.quandex.ui.theme.Gold
import com.quanda.quandex.ui.theme.Green
import com.quanda.quandex.ui.theme.Muted
import com.quanda.quandex.ui.theme.Night
import com.quanda.quandex.ui.theme.Red

@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardColor),
        border = BorderStroke(1.dp, Border),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun RowScope.MetricCard(
    title: String,
    value: String,
    valueColor: Color = Color.White
) {
    Card(
        modifier = Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = CardColor),
        border = BorderStroke(1.dp, Border),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = Muted, fontSize = 10.sp, maxLines = 1)
            Spacer(Modifier.height(5.dp))
            Text(value, color = valueColor, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
fun TradingButton(
    text: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Night,
            contentColor = color,
            disabledContainerColor = Night.copy(alpha = 0.6f),
            disabledContentColor = Muted
        ),
        border = BorderStroke(1.dp, if (enabled) color else Border),
        shape = RoundedCornerShape(9.dp)
    ) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun KeyValue(label: String, value: String, valueColor: Color = Color.White) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.width(12.dp))
        Text(value, color = valueColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TrendBadge(label: String, trend: Trend, modifier: Modifier = Modifier) {
    val color = when (trend) {
        Trend.BULLISH -> Green
        Trend.BEARISH -> Red
        Trend.NEUTRAL -> Gold
    }
    Column(
        modifier = modifier
            .background(Night, RoundedCornerShape(8.dp))
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Text(trend.displayName(), color = color, fontSize = 10.sp)
    }
}

@Composable
fun DirectionPill(direction: Direction) {
    val color = when (direction) {
        Direction.BUY -> Green
        Direction.SELL -> Red
        Direction.NEUTRAL -> Gold
    }
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(direction.displayName(), color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
fun FormField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    keyboardOptions: KeyboardOptions,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    visualTransformation: androidx.compose.ui.text.input.VisualTransformation = androidx.compose.ui.text.input.VisualTransformation.None
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        singleLine = singleLine,
        keyboardOptions = keyboardOptions,
        visualTransformation = visualTransformation
    )
}

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Muted, style = MaterialTheme.typography.bodyMedium)
    }
}

fun Direction.displayName(): String = when (this) {
    Direction.BUY -> "ACHAT"
    Direction.SELL -> "VENTE"
    Direction.NEUTRAL -> "AUCUN"
}

fun Trend.displayName(): String = when (this) {
    Trend.BULLISH -> "HAUSSE"
    Trend.BEARISH -> "BAISSE"
    Trend.NEUTRAL -> "NEUTRE"
}
