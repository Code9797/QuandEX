package com.quanda.quandex.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.quanda.quandex.R
import com.quanda.quandex.data.Direction
import com.quanda.quandex.data.Trend
import com.quanda.quandex.data.UiState
import com.quanda.quandex.ui.components.KeyValue
import com.quanda.quandex.ui.components.MetricCard
import com.quanda.quandex.ui.components.SectionCard
import com.quanda.quandex.ui.components.TradingButton
import com.quanda.quandex.ui.components.TrendBadge
import com.quanda.quandex.ui.components.displayName
import com.quanda.quandex.ui.theme.Blue
import com.quanda.quandex.ui.theme.Gold
import com.quanda.quandex.ui.theme.Green
import com.quanda.quandex.ui.theme.Muted
import com.quanda.quandex.ui.theme.Red
import java.util.Locale

@Composable
fun DashboardScreen(
    state: UiState,
    onToggleAuto: () -> Unit,
    onBuy: () -> Unit,
    onSell: () -> Unit,
    onCloseAll: () -> Unit
) {
    val dashboard = state.snapshot.dashboard
    var confirmCloseAll by remember { mutableStateOf(false) }
    val signalColor = directionColor(dashboard.signal)
    val trendColor = trendColor(dashboard.trend)

    if (confirmCloseAll) {
        AlertDialog(
            onDismissRequest = { confirmCloseAll = false },
            title = { Text("Fermer toutes les positions ?") },
            text = { Text("Cette commande sera transmise immédiatement à la passerelle QuandEX.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmCloseAll = false
                    onCloseAll()
                }) { Text("FERMER", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = { confirmCloseAll = false }) { Text("ANNULER") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(R.drawable.quandex_logo),
                        contentDescription = "Logo QuandEX",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(62.dp)
                            .clip(RoundedCornerShape(14.dp))
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            "QUANDEX MOBILE",
                            color = Gold,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "${dashboard.symbol}  •  ${dashboard.timeframe}  •  MULTI-TIMEFRAME",
                            color = Muted,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        if (state.settings.demoMode) "DÉMO" else if (dashboard.connected) "LIVE" else "HORS LIGNE",
                        color = if (dashboard.connected) Green else Red,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                if (state.loading) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold)
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("EA STATUS", if (dashboard.connected) "ACTIF" else "OFFLINE", if (dashboard.connected) Green else Red)
                MetricCard("TENDANCE", dashboard.trend.displayName(), trendColor)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("SIGNAL", dashboard.signal.displayName(), signalColor)
                MetricCard("SPREAD", number(dashboard.spreadPoints, 1) + " pts", Color.White)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("BALANCE", money(dashboard.balance, dashboard.currency))
                MetricCard("EQUITY", money(dashboard.equity, dashboard.currency))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard(
                    "PROFIT JOUR",
                    signedMoney(dashboard.dailyProfit, dashboard.currency),
                    if (dashboard.dailyProfit >= 0.0) Green else Red
                )
                MetricCard("WIN RATE 7J", number(dashboard.winRate7d, 1) + "%", Green)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("RISQUE / TRADE", number(dashboard.riskPercent, 2) + "%")
                MetricCard("LOT ESTIMÉ", number(dashboard.estimatedLot, 2) + " lot", Gold)
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TradingButton(
                    if (dashboard.autoTrading) "AUTO ON" else "AUTO OFF",
                    if (dashboard.autoTrading) Green else Gold,
                    onToggleAuto,
                    Modifier.weight(1f),
                    !state.commandInProgress
                )
                TradingButton("BUY", Green, onBuy, Modifier.weight(1f), !state.commandInProgress)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TradingButton("SELL", Red, onSell, Modifier.weight(1f), !state.commandInProgress)
                TradingButton("CLOSE ALL", Gold, { confirmCloseAll = true }, Modifier.weight(1f), !state.commandInProgress)
            }
        }

        item {
            SectionCard("ALIGNEMENT MULTI-TIMEFRAME") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    dashboard.mtf.forEach {
                        TrendBadge(it.timeframe, it.trend, Modifier.weight(1f))
                    }
                }
            }
        }

        item {
            SectionCard("RISK MANAGEMENT") {
                KeyValue("Stop Loss", price(dashboard.risk.stopLoss))
                Spacer(Modifier.height(7.dp))
                KeyValue("Take Profit", price(dashboard.risk.takeProfit))
                Spacer(Modifier.height(7.dp))
                KeyValue("Trailing Stop", number(dashboard.risk.trailingPoints, 1) + " points", Gold)
                Spacer(Modifier.height(7.dp))
                KeyValue("Break-even", if (dashboard.risk.breakEvenEnabled) "ACTIF" else "INACTIF", Green)
                Spacer(Modifier.height(7.dp))
                KeyValue(
                    "Risque global",
                    number(dashboard.globalRiskPercent, 2) + "%",
                    if (dashboard.globalRiskPercent > 1.0) Red else Green
                )
                Spacer(Modifier.height(7.dp))
                KeyValue("Drawdown journalier", number(dashboard.dailyDrawdown, 2) + "%")
            }
        }

        item {
            SectionCard("CONDITIONS DE MARCHÉ & ROBOT") {
                KeyValue("Stratégie", dashboard.strategy, signalColor)
                Spacer(Modifier.height(7.dp))
                KeyValue("Confiance", number(dashboard.confidence, 1) + "%", Gold)
                Spacer(Modifier.height(7.dp))
                KeyValue("RSI", number(dashboard.market.rsi, 1))
                Spacer(Modifier.height(7.dp))
                KeyValue("ADX", number(dashboard.market.adx, 1))
                Spacer(Modifier.height(7.dp))
                KeyValue("ATR", number(dashboard.market.atrPoints, 1) + " points")
                Spacer(Modifier.height(7.dp))
                KeyValue("Régime", dashboard.market.regime, Blue)
                Spacer(Modifier.height(7.dp))
                KeyValue("Session", dashboard.market.session)
                Spacer(Modifier.height(7.dp))
                KeyValue("News", if (dashboard.market.newsBlocked) "BLOQUÉ" else "OK", if (dashboard.market.newsBlocked) Red else Green)
                Spacer(Modifier.height(7.dp))
                KeyValue("Trades du jour", dashboard.dailyTrades.toString())
            }
        }

        item {
            SectionCard("SMART MONEY — ORDER BLOCK & IMBALANCE") {
                KeyValue("Order Block haussier", yesNo(dashboard.smc.bullishOrderBlock), if (dashboard.smc.bullishOrderBlock) Green else Muted)
                Spacer(Modifier.height(7.dp))
                KeyValue("Order Block baissier", yesNo(dashboard.smc.bearishOrderBlock), if (dashboard.smc.bearishOrderBlock) Red else Muted)
                Spacer(Modifier.height(7.dp))
                KeyValue("FVG haussière", yesNo(dashboard.smc.bullishFvg), if (dashboard.smc.bullishFvg) Green else Muted)
                Spacer(Modifier.height(7.dp))
                KeyValue("FVG baissière", yesNo(dashboard.smc.bearishFvg), if (dashboard.smc.bearishFvg) Red else Muted)
                Spacer(Modifier.height(7.dp))
                KeyValue("Niveau OB", price(dashboard.smc.orderBlockPrice), Gold)
            }
        }

        item {
            Text(
                text = "Dernier événement : ${dashboard.lastEvent}",
                color = Muted,
                fontSize = 11.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}

private fun number(value: Double, decimals: Int): String =
    String.format(Locale.US, "%.${decimals}f", value)

private fun price(value: Double): String = if (value > 0.0) number(value, 2) else "--"
private fun money(value: Double, currency: String) = "${number(value, 2)} $currency"
private fun signedMoney(value: Double, currency: String) = "${if (value >= 0) "+" else ""}${number(value, 2)} $currency"
private fun yesNo(value: Boolean) = if (value) "ACTIF" else "AUCUN"

private fun directionColor(direction: Direction): Color = when (direction) {
    Direction.BUY -> Green
    Direction.SELL -> Red
    Direction.NEUTRAL -> Gold
}

private fun trendColor(trend: Trend): Color = when (trend) {
    Trend.BULLISH -> Green
    Trend.BEARISH -> Red
    Trend.NEUTRAL -> Gold
}
