package com.quanda.quandex.ui

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.quanda.quandex.R
import com.quanda.quandex.ui.screens.DashboardScreen
import com.quanda.quandex.ui.screens.PositionsScreen
import com.quanda.quandex.ui.screens.SettingsScreen
import com.quanda.quandex.ui.screens.SignalsScreen
import com.quanda.quandex.ui.screens.TradingScreen
import com.quanda.quandex.ui.theme.Gold
import com.quanda.quandex.ui.theme.Panel

private data class Destination(val route: String, val label: String, val icon: ImageVector)

private val destinations = listOf(
    Destination("dashboard", "Accueil", Icons.Default.Home),
    Destination("signals", "Signaux", Icons.Default.ShowChart),
    Destination("trading", "Trading", Icons.Default.SwapVert),
    Destination("positions", "Positions", Icons.Default.AccountBalanceWallet),
    Destination("settings", "Réglages", Icons.Default.Settings)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuandExApp(viewModel: MainViewModel) {
    val state by viewModel.uiState.collectAsState()
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: "dashboard"
    val snackbarHostState = remember { SnackbarHostState() }
    val toneGenerator = remember { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80) }

    DisposableEffect(Unit) {
        onDispose { toneGenerator.release() }
    }

    LaunchedEffect(state.message) {
        state.message?.let {
            val isTradingEvent = it.contains("ordre", ignoreCase = true) ||
                it.contains("position", ignoreCase = true) ||
                it.contains("AUTO", ignoreCase = true)
            if (isTradingEvent) {
                val rejected = it.contains("refus", ignoreCase = true) ||
                    it.contains("échec", ignoreCase = true) ||
                    it.contains("introuvable", ignoreCase = true)
                toneGenerator.startTone(
                    if (rejected) ToneGenerator.TONE_PROP_NACK else ToneGenerator.TONE_PROP_ACK,
                    180
                )
            }
            snackbarHostState.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    fun navigate(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 720.dp
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(R.drawable.quandex_logo),
                                contentDescription = "Logo QuandEX",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            )
                            Spacer(Modifier.width(9.dp))
                            Text(
                                text = "QuandEX  •  ${state.snapshot.dashboard.symbol}",
                                color = Gold,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = viewModel::refreshNow) {
                            Icon(Icons.Default.Refresh, contentDescription = "Actualiser")
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Panel)
                )
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(containerColor = Panel) {
                        destinations.forEach { destination ->
                            NavigationBarItem(
                                selected = currentRoute == destination.route,
                                onClick = { navigate(destination.route) },
                                icon = { Icon(destination.icon, contentDescription = destination.label) },
                                label = { Text(destination.label) }
                            )
                        }
                    }
                }
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { padding ->
            Row(Modifier.fillMaxSize().padding(padding)) {
                if (useRail) {
                    NavigationRail(containerColor = Panel) {
                        destinations.forEach { destination ->
                            NavigationRailItem(
                                selected = currentRoute == destination.route,
                                onClick = { navigate(destination.route) },
                                icon = { Icon(destination.icon, contentDescription = destination.label) },
                                label = { Text(destination.label) }
                            )
                        }
                    }
                }
                Box(Modifier.weight(1f)) {
                    NavHost(navController = navController, startDestination = "dashboard") {
                        composable("dashboard") {
                            DashboardScreen(
                                state = state,
                                onToggleAuto = viewModel::toggleAuto,
                                onBuy = { viewModel.quickTrade(com.quanda.quandex.data.Direction.BUY) },
                                onSell = { viewModel.quickTrade(com.quanda.quandex.data.Direction.SELL) },
                                onCloseAll = viewModel::closeAll
                            )
                        }
                        composable("signals") { SignalsScreen(state.snapshot.signals) }
                        composable("trading") {
                            TradingScreen(
                                state = state,
                                onExecute = viewModel::execute,
                                onClosePending = viewModel::closePending,
                                onCloseAll = viewModel::closeAll
                            )
                        }
                        composable("positions") {
                            PositionsScreen(
                                positions = state.snapshot.positions,
                                commandInProgress = state.commandInProgress,
                                onClose = viewModel::closePosition,
                                onCloseAll = viewModel::closeAll
                            )
                        }
                        composable("settings") {
                            SettingsScreen(state.settings, viewModel::saveSettings)
                        }
                    }
                }
            }
        }
    }
}
