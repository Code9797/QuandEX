package com.quanda.quandex.network

import com.quanda.quandex.data.AppSettings
import com.quanda.quandex.data.CommandResult
import com.quanda.quandex.data.Dashboard
import com.quanda.quandex.data.Direction
import com.quanda.quandex.data.MarketConditions
import com.quanda.quandex.data.OrderType
import com.quanda.quandex.data.PositionItem
import com.quanda.quandex.data.RiskLevels
import com.quanda.quandex.data.SignalItem
import com.quanda.quandex.data.SmcState
import com.quanda.quandex.data.Snapshot
import com.quanda.quandex.data.TimeframeTrend
import com.quanda.quandex.data.TradeTicket
import com.quanda.quandex.data.TradingCommand
import com.quanda.quandex.data.Trend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class QuandExApi {
    suspend fun fetchSnapshot(settings: AppSettings): Snapshot = withContext(Dispatchers.IO) {
        val symbol = java.net.URLEncoder.encode(settings.symbol, Charsets.UTF_8.name())
        val body = request(settings, "GET", "/api/v1/snapshot?symbol=$symbol")
        parseSnapshot(JSONObject(body))
    }

    suspend fun sendCommand(
        settings: AppSettings,
        command: TradingCommand
    ): CommandResult = withContext(Dispatchers.IO) {
        val payload = commandJson(command)
        val body = request(settings, "POST", "/api/v1/commands", payload.toString())
        val json = JSONObject(body)
        CommandResult(
            accepted = json.optBoolean("accepted", false),
            message = json.optString("message", "Réponse reçue"),
            affectedCount = json.optInt("affectedCount", 0)
        )
    }

    private fun request(
        settings: AppSettings,
        method: String,
        path: String,
        payload: String? = null
    ): String {
        val base = settings.apiBaseUrl.trim().trimEnd('/')
        require(base.startsWith("https://") || base.startsWith("http://")) {
            "URL de passerelle invalide"
        }
        val connection = (URL(base + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 8_000
            readTimeout = 8_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (settings.apiToken.isNotBlank()) {
                setRequestProperty("Authorization", "Bearer ${settings.apiToken}")
            }
            if (payload != null) doOutput = true
        }
        return try {
            if (payload != null) {
                connection.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(payload) }
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val message = runCatching { JSONObject(response).optString("message") }.getOrNull()
                error(message?.takeIf { it.isNotBlank() } ?: "Erreur HTTP $status")
            }
            response
        } finally {
            connection.disconnect()
        }
    }

    private fun commandJson(command: TradingCommand): JSONObject = when (command) {
        is TradingCommand.ToggleAuto -> JSONObject()
            .put("command", "TOGGLE_AUTO")
            .put("enabled", command.enabled)

        is TradingCommand.Execute -> JSONObject()
            .put("command", "EXECUTE")
            .put("ticket", ticketJson(command.ticket))

        TradingCommand.CloseAll -> JSONObject().put("command", "CLOSE_ALL")
        TradingCommand.ClosePending -> JSONObject().put("command", "CLOSE_PENDING")
        is TradingCommand.ClosePosition -> JSONObject()
            .put("command", "CLOSE_POSITION")
            .put("ticket", command.ticket)
    }

    private fun ticketJson(ticket: TradeTicket) = JSONObject()
        .put("direction", ticket.direction.name)
        .put("orderType", ticket.orderType.name)
        .put("entry", ticket.entry)
        .put("stopLoss", ticket.stopLoss)
        .put("takeProfit", ticket.takeProfit)
        .put("lot", ticket.lot)
        .put("gridPoints", ticket.gridPoints)
        .put("orderCount", ticket.orderCount)
        .put("trailing", ticket.trailing)
        .put("keepGrid", ticket.keepGrid)

    private fun parseSnapshot(root: JSONObject): Snapshot {
        val dashboardJson = root.optJSONObject("dashboard") ?: root
        val riskJson = dashboardJson.optJSONObject("risk") ?: JSONObject()
        val marketJson = dashboardJson.optJSONObject("market") ?: JSONObject()
        val smcJson = dashboardJson.optJSONObject("smc") ?: JSONObject()
        val mtfJson = dashboardJson.optJSONArray("mtf") ?: JSONArray()
        val dashboard = Dashboard(
            symbol = dashboardJson.optString("symbol", "XAUUSD"),
            timeframe = dashboardJson.optString("timeframe", "M5"),
            connected = dashboardJson.optBoolean("connected", true),
            autoTrading = dashboardJson.optBoolean("autoTrading", false),
            trend = trend(dashboardJson.optString("trend")),
            signal = direction(dashboardJson.optString("signal")),
            confidence = dashboardJson.optDouble("confidence", 0.0),
            strategy = dashboardJson.optString("strategy", "Aucun consensus"),
            lastPrice = dashboardJson.optDouble("lastPrice", 0.0),
            spreadPoints = dashboardJson.optDouble("spreadPoints", 0.0),
            balance = dashboardJson.optDouble("balance", 0.0),
            equity = dashboardJson.optDouble("equity", 0.0),
            dailyProfit = dashboardJson.optDouble("dailyProfit", 0.0),
            winRate7d = dashboardJson.optDouble("winRate7d", 0.0),
            riskPercent = dashboardJson.optDouble("riskPercent", 1.0),
            globalRiskPercent = dashboardJson.optDouble("globalRiskPercent", 0.0),
            estimatedLot = dashboardJson.optDouble("estimatedLot", 0.01),
            currency = dashboardJson.optString("currency", "USD"),
            dailyDrawdown = dashboardJson.optDouble("dailyDrawdown", 0.0),
            dailyTrades = dashboardJson.optInt("dailyTrades", 0),
            riskLocked = dashboardJson.optBoolean("riskLocked", false),
            lastEvent = dashboardJson.optString("lastEvent", "Données reçues"),
            risk = RiskLevels(
                stopLoss = riskJson.optDouble("stopLoss", 0.0),
                takeProfit = riskJson.optDouble("takeProfit", 0.0),
                trailingPoints = riskJson.optDouble("trailingPoints", 0.0),
                breakEvenEnabled = riskJson.optBoolean("breakEvenEnabled", true)
            ),
            market = MarketConditions(
                rsi = marketJson.optDouble("rsi", 0.0),
                adx = marketJson.optDouble("adx", 0.0),
                atrPoints = marketJson.optDouble("atrPoints", 0.0),
                regime = marketJson.optString("regime", "INCONNU"),
                newsBlocked = marketJson.optBoolean("newsBlocked", false),
                session = marketJson.optString("session", "FERMÉE")
            ),
            smc = SmcState(
                bullishOrderBlock = smcJson.optBoolean("bullishOrderBlock", false),
                bearishOrderBlock = smcJson.optBoolean("bearishOrderBlock", false),
                bullishFvg = smcJson.optBoolean("bullishFvg", false),
                bearishFvg = smcJson.optBoolean("bearishFvg", false),
                orderBlockPrice = smcJson.optDouble("orderBlockPrice", 0.0)
            ),
            mtf = (0 until mtfJson.length()).map { index ->
                val item = mtfJson.optJSONObject(index) ?: JSONObject()
                TimeframeTrend(item.optString("timeframe", "--"), trend(item.optString("trend")))
            }.ifEmpty { Dashboard().mtf }
        )
        return Snapshot(
            dashboard = dashboard,
            signals = parseSignals(root.optJSONArray("signals") ?: JSONArray()),
            positions = parsePositions(root.optJSONArray("positions") ?: JSONArray()),
            receivedAt = System.currentTimeMillis()
        )
    }

    private fun parseSignals(values: JSONArray): List<SignalItem> =
        (0 until values.length()).map { index ->
            val item = values.optJSONObject(index) ?: JSONObject()
            SignalItem(
                id = item.optString("id", index.toString()),
                time = item.optString("time", "--"),
                symbol = item.optString("symbol", "XAUUSD"),
                timeframe = item.optString("timeframe", "M5"),
                direction = direction(item.optString("direction")),
                strategy = item.optString("strategy", "QuandEX"),
                confidence = item.optDouble("confidence", 0.0),
                entry = item.optDouble("entry", 0.0),
                stopLoss = item.optDouble("stopLoss", 0.0),
                takeProfit = item.optDouble("takeProfit", 0.0),
                status = item.optString("status", "NOUVEAU")
            )
        }

    private fun parsePositions(values: JSONArray): List<PositionItem> =
        (0 until values.length()).map { index ->
            val item = values.optJSONObject(index) ?: JSONObject()
            PositionItem(
                ticket = item.optLong("ticket", 0L),
                symbol = item.optString("symbol", "XAUUSD"),
                direction = direction(item.optString("direction")),
                volume = item.optDouble("volume", 0.0),
                entry = item.optDouble("entry", 0.0),
                currentPrice = item.optDouble("currentPrice", 0.0),
                stopLoss = item.optDouble("stopLoss", 0.0),
                takeProfit = item.optDouble("takeProfit", 0.0),
                profit = item.optDouble("profit", 0.0),
                comment = item.optString("comment", "QuandEX")
            )
        }

    private fun direction(value: String): Direction = when (value.uppercase()) {
        "BUY", "ACHAT", "BULLISH" -> Direction.BUY
        "SELL", "VENTE", "BEARISH" -> Direction.SELL
        else -> Direction.NEUTRAL
    }

    private fun trend(value: String): Trend = when (value.uppercase()) {
        "BUY", "HAUSSE", "BULLISH" -> Trend.BULLISH
        "SELL", "BAISSE", "BEARISH" -> Trend.BEARISH
        else -> Trend.NEUTRAL
    }
}
