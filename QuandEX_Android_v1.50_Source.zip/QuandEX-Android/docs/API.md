# Contrat API QuandEX Mobile

L’application Android dialogue avec une passerelle HTTPS. Cette passerelle est responsable de l’authentification, de la communication avec le terminal MT5 et de toutes les vérifications de risque côté serveur.

## Authentification

Si un jeton est configuré, chaque requête contient :

```http
Authorization: Bearer VOTRE_JETON
```

En production, utilisez uniquement HTTPS, un jeton révocable, une expiration courte et une liste blanche d’appareils ou d’adresses IP.

## `GET /api/v1/snapshot?symbol=XAUUSD`

Retourne l’état complet du tableau :

```json
{
  "dashboard": {
    "symbol": "XAUUSD",
    "timeframe": "M5",
    "connected": true,
    "autoTrading": true,
    "trend": "BULLISH",
    "signal": "BUY",
    "confidence": 74.5,
    "strategy": "EMA Pullback + Order Block",
    "lastPrice": 2640.5,
    "spreadPoints": 21,
    "balance": 7723.75,
    "equity": 7807.95,
    "dailyProfit": 84.2,
    "winRate7d": 68.4,
    "riskPercent": 1.0,
    "globalRiskPercent": 0.8,
    "estimatedLot": 0.01,
    "currency": "USD",
    "dailyDrawdown": 0.0,
    "dailyTrades": 3,
    "riskLocked": false,
    "lastEvent": "Données reçues",
    "risk": { "stopLoss": 2634.1, "takeProfit": 2653.3, "trailingPoints": 640, "breakEvenEnabled": true },
    "market": { "rsi": 56.2, "adx": 28.1, "atrPoints": 640, "regime": "TENDANCE", "newsBlocked": false, "session": "LONDRES–NEW YORK" },
    "smc": { "bullishOrderBlock": true, "bearishOrderBlock": false, "bullishFvg": true, "bearishFvg": false, "orderBlockPrice": 2637.3 },
    "mtf": [{ "timeframe": "H1", "trend": "BULLISH" }]
  },
  "signals": [],
  "positions": []
}
```

Valeurs reconnues : `BUY`, `SELL`, `NEUTRAL`, `BULLISH` et `BEARISH`.

## `POST /api/v1/commands`

### Activation automatique

```json
{ "command": "TOGGLE_AUTO", "enabled": true }
```

### Exécution

```json
{
  "command": "EXECUTE",
  "ticket": {
    "direction": "BUY",
    "orderType": "MARKET",
    "entry": 2640.5,
    "stopLoss": 2634.1,
    "takeProfit": 2653.3,
    "lot": 0.01,
    "gridPoints": 0,
    "orderCount": 1,
    "trailing": true,
    "keepGrid": false
  }
}
```

Autres commandes : `CLOSE_ALL`, `CLOSE_PENDING` et `CLOSE_POSITION` avec la propriété numérique `ticket`.

Réponse commune :

```json
{ "accepted": true, "message": "Ordre accepté", "affectedCount": 1 }
```

La passerelle doit rester l’autorité finale : recalcul du lot, contrôle du SL réel, limites journalières, spread, marge, sessions, drawdown et anti-rejeu avant tout ordre MT5.
