#!/usr/bin/env node
const http = require("http");

const port = Number(process.env.QUANDEX_PORT || 8080);
let autoTrading = true;
let nextTicket = 100001;
let positions = [];
let signals = [];

function json(response, status, body) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  response.end(JSON.stringify(body));
}

function snapshot() {
  const wave = Math.sin(Date.now() / 12000);
  const price = 2640 + wave * 4.6;
  const trend = wave > 0.15 ? "BULLISH" : wave < -0.15 ? "BEARISH" : "NEUTRAL";
  const signal = wave > 0.35 ? "BUY" : wave < -0.35 ? "SELL" : "NEUTRAL";
  positions = positions.map((position) => {
    const distance = position.direction === "BUY" ? price - position.entry : position.entry - price;
    return { ...position, currentPrice: price, profit: distance * position.volume * 100 };
  });
  const floating = positions.reduce((sum, item) => sum + item.profit, 0);
  return {
    dashboard: {
      symbol: "XAUUSD",
      timeframe: "M5",
      connected: true,
      autoTrading,
      trend,
      signal,
      confidence: 74.5,
      strategy: "EMA Pullback + Order Block",
      lastPrice: price,
      spreadPoints: 21.0,
      balance: 7723.75,
      equity: 7723.75 + floating,
      dailyProfit: 84.2 + floating,
      winRate7d: 68.4,
      riskPercent: 1.0,
      globalRiskPercent: positions.length,
      estimatedLot: 0.01,
      currency: "USD",
      dailyDrawdown: 0.0,
      dailyTrades: 3 + positions.length,
      riskLocked: false,
      lastEvent: "Passerelle de démonstration active",
      risk: { stopLoss: price - 6.4, takeProfit: price + 12.8, trailingPoints: 640, breakEvenEnabled: true },
      market: { rsi: 56.2, adx: 28.1, atrPoints: 640, regime: "TENDANCE", newsBlocked: false, session: "LONDRES–NEW YORK" },
      smc: { bullishOrderBlock: true, bearishOrderBlock: false, bullishFvg: true, bearishFvg: false, orderBlockPrice: price - 3.2 },
      mtf: [
        { timeframe: "MN1", trend: "BULLISH" },
        { timeframe: "D1", trend },
        { timeframe: "H4", trend },
        { timeframe: "H1", trend },
        { timeframe: "M15", trend: wave >= 0 ? "BULLISH" : "BEARISH" }
      ]
    },
    signals,
    positions
  };
}

function execute(ticket) {
  const position = {
    ticket: nextTicket++,
    symbol: "XAUUSD",
    direction: ticket.direction,
    volume: ticket.lot,
    entry: ticket.entry,
    currentPrice: ticket.entry,
    stopLoss: ticket.stopLoss,
    takeProfit: ticket.takeProfit,
    profit: 0,
    comment: "QuandEX Mobile Mock"
  };
  positions.unshift(position);
  signals.unshift({
    id: String(position.ticket),
    time: new Date().toLocaleTimeString("fr-FR"),
    symbol: position.symbol,
    timeframe: "M5",
    direction: position.direction,
    strategy: "Commande mobile",
    confidence: 75,
    entry: position.entry,
    stopLoss: position.stopLoss,
    takeProfit: position.takeProfit,
    status: "EXÉCUTÉ"
  });
  signals = signals.slice(0, 20);
  return { accepted: true, message: `Ordre #${position.ticket} accepté`, affectedCount: 1 };
}

const server = http.createServer((request, response) => {
  const url = new URL(request.url, `http://${request.headers.host}`);
  if (request.method === "GET" && url.pathname === "/api/v1/snapshot") {
    return json(response, 200, snapshot());
  }
  if (request.method !== "POST" || url.pathname !== "/api/v1/commands") {
    return json(response, 404, { message: "Route inconnue" });
  }

  let raw = "";
  request.on("data", (chunk) => { raw += chunk; });
  request.on("end", () => {
    try {
      const command = JSON.parse(raw || "{}");
      if (command.command === "TOGGLE_AUTO") {
        autoTrading = Boolean(command.enabled);
        return json(response, 200, { accepted: true, message: `AUTO ${autoTrading ? "ON" : "OFF"}`, affectedCount: 1 });
      }
      if (command.command === "EXECUTE") return json(response, 200, execute(command.ticket));
      if (command.command === "CLOSE_ALL") {
        const count = positions.length;
        positions = [];
        return json(response, 200, { accepted: true, message: `${count} position(s) fermée(s)`, affectedCount: count });
      }
      if (command.command === "CLOSE_PENDING") {
        return json(response, 200, { accepted: true, message: "Ordres en attente supprimés", affectedCount: 0 });
      }
      if (command.command === "CLOSE_POSITION") {
        const before = positions.length;
        positions = positions.filter((item) => item.ticket !== Number(command.ticket));
        const count = before - positions.length;
        return json(response, count ? 200 : 404, { accepted: count === 1, message: count ? "Position fermée" : "Position introuvable", affectedCount: count });
      }
      return json(response, 400, { accepted: false, message: "Commande invalide", affectedCount: 0 });
    } catch (error) {
      return json(response, 400, { accepted: false, message: error.message, affectedCount: 0 });
    }
  });
});

server.listen(port, "0.0.0.0", () => {
  console.log(`QuandEX mock API: http://127.0.0.1:${port}`);
});
